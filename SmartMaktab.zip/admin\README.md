# SmartMaktab Admin

Admin panel uchun keyingi bosqich arxitekturasi:
- Admin login va role-based access control
- Muammolar ro'yxati, qidiruv va filtrlar
- Holatni o'zgartirish va yechim izohini kiritish
- Maktablar va kategoriyalarni boshqarish
- Moderatsiya navbati va audit jurnali

Hozirgi backendda statusni o'zgartiruvchi endpoint MVP maqsadida mavjud, lekin admin autentifikatsiyasi hali yo'q. Shu sababli backendni ommaviy internetga admin himoyasisiz chiqarmang.
