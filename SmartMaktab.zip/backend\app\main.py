from datetime import datetime, timezone
from enum import Enum
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import SQLModel, Field, Session, create_engine, select

DATABASE_URL = "sqlite:///./smartmaktab.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

class Status(str, Enum):
    submitted = "Yangi yuborildi"
    reviewing = "Tekshirilmoqda"
    approved = "Tasdiqlandi"
    assigned = "Mas'ulga yuborildi"
    progress = "Hal qilinmoqda"
    resolved = "Hal qilindi"
    rejected = "Rad etildi"

class Problem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    description: str
    school: str
    category: str
    priority: str = "O‘rtacha"
    status: str = Status.submitted.value
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    resolution_note: Optional[str] = None

class ProblemCreate(SQLModel):
    title: str
    description: str
    school: str
    category: str
    priority: str = "O‘rtacha"

class StatusUpdate(SQLModel):
    status: str
    resolution_note: Optional[str] = None

app = FastAPI(title="SmartMaktab API", version="1.0.0",
              description="SmartMaktab maktab muammolarini yuborish va kuzatish API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Productionda aniq domenlar bilan cheklang.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    SQLModel.metadata.create_all(engine)

@app.get("/")
def root():
    return {"app": "SmartMaktab", "status": "running", "docs": "/docs"}

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/api/v1/categories")
def categories():
    return [
        "Sinfxona", "Parta va stullar", "Isitish va sovitish", "Elektr",
        "Internet va kompyuter", "Hojatxona", "Ichimlik suvi", "Oshxona",
        "Tozalik", "Bino ta'miri", "Deraza va eshik", "Sport maydoni",
        "Kutubxona", "O'quv materiallari", "Qulay kirish", "Xavfsizlik", "Boshqa"
    ]

@app.get("/api/v1/problems", response_model=list[Problem])
def list_problems(school: Optional[str] = None, status: Optional[str] = None):
    with Session(engine) as session:
        query = select(Problem).order_by(Problem.created_at.desc())
        if school:
            query = query.where(Problem.school == school)
        if status:
            query = query.where(Problem.status == status)
        return session.exec(query).all()

@app.post("/api/v1/problems", response_model=Problem)
def create_problem(payload: ProblemCreate):
    if not payload.title.strip() or not payload.description.strip():
        raise HTTPException(status_code=400, detail="Sarlavha va tavsifni kiriting")
    if len(payload.title) > 120 or len(payload.description) > 4000:
        raise HTTPException(status_code=400, detail="Matn uzunligi me'yordan oshdi")
    with Session(engine) as session:
        item = Problem(**payload.model_dump())
        session.add(item)
        session.commit()
        session.refresh(item)
        return item

@app.get("/api/v1/problems/{problem_id}", response_model=Problem)
def get_problem(problem_id: int):
    with Session(engine) as session:
        item = session.get(Problem, problem_id)
        if not item:
            raise HTTPException(status_code=404, detail="Muammo topilmadi")
        return item

@app.patch("/api/v1/problems/{problem_id}/status", response_model=Problem)
def update_status(problem_id: int, payload: StatusUpdate):
    # MVP: admin autentifikatsiyasi hali qo'shilmagan. Internetga ochiq qo'ymang.
    allowed = {s.value for s in Status}
    if payload.status not in allowed:
        raise HTTPException(status_code=400, detail="Noto'g'ri holat")
    if payload.status == Status.resolved.value and not (payload.resolution_note or "").strip():
        raise HTTPException(status_code=400, detail="Yechim izohini kiriting")
    with Session(engine) as session:
        item = session.get(Problem, problem_id)
        if not item:
            raise HTTPException(status_code=404, detail="Muammo topilmadi")
        item.status = payload.status
        item.resolution_note = payload.resolution_note
        session.add(item)
        session.commit()
        session.refresh(item)
        return item
