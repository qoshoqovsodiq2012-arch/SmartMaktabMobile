import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000',
);

void main() => runApp(const SmartMaktabApp());

class SmartMaktabApp extends StatelessWidget {
  const SmartMaktabApp({super.key});
  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF2563EB);
    return MaterialApp(
      title: 'SmartMaktab',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F7FB)),
        cardTheme: CardThemeData(elevation: 0, color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      ),
      home: const MainShell(),
    );
  }
}

class Api {
  static Future<List<dynamic>> problems() async {
    final r = await http.get(Uri.parse('$apiBaseUrl/api/v1/problems'))
        .timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) throw Exception('Server javobi: ${r.statusCode}');
    return jsonDecode(r.body) as List<dynamic>;
  }

  static Future<void> create(Map<String, String> data) async {
    final r = await http.post(Uri.parse('$apiBaseUrl/api/v1/problems'),
      headers: {'Content-Type': 'application/json'}, body: jsonEncode(data))
      .timeout(const Duration(seconds: 12));
    if (r.statusCode != 200) {
      final body = jsonDecode(r.body);
      throw Exception(body['detail'] ?? 'Yuborishda xatolik');
    }
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  void go(int index) => setState(() => tab = index);
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onNavigate: go),
      const ProblemsPage(),
      ReportPage(onSent: () => go(1)),
      const NoticesPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: go,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Bosh sahifa'),
          NavigationDestination(icon: Icon(Icons.report_outlined), selectedIcon: Icon(Icons.report), label: 'Muammolar'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Yuborish'),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'Xabarlar'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const HomePage({super.key, required this.onNavigate});
  @override
  Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: () async { await Api.problems(); },
    child: ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [
        Container(width: 46, height: 46, decoration: BoxDecoration(
          color: const Color(0xFFDBEAFE), borderRadius: BorderRadius.circular(15)),
          child: const Icon(Icons.school, color: Color(0xFF1D4ED8))),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('SmartMaktab', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          Text('Maktabni birgalikda yaxshilaymiz', style: TextStyle(color: Colors.black54)),
        ])),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      ]),
      const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1D4ED8), Color(0xFF3B82F6)]),
        borderRadius: BorderRadius.circular(24)), child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Muammoni ko‘rdingizmi?', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Xabar bering — yechim sari birinchi qadamni birga tashlaymiz.',
              style: TextStyle(color: Colors.white70)),
          ])),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: _ActionCard(icon: Icons.add_a_photo_outlined, title: 'Muammo yuborish',
          subtitle: 'Yangi murojaat', onTap: () => onNavigate(2))),
        const SizedBox(width: 12),
        Expanded(child: _ActionCard(icon: Icons.search, title: 'Muammolar', subtitle: 'Ko‘rib chiqish',
          onTap: () => onNavigate(1))),
      ]),
      const SizedBox(height: 24),
      const Text('Platforma bo‘limlari', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Wrap(spacing: 10, runSpacing: 10, children: [
        _Pill(icon: Icons.location_city, label: 'Maktablar'),
        _Pill(icon: Icons.map_outlined, label: 'Xarita'),
        _Pill(icon: Icons.bar_chart, label: 'Statistika'),
        _Pill(icon: Icons.lightbulb_outline, label: 'Yechimlar'),
        _Pill(icon: Icons.menu_book_outlined, label: 'Darslar'),
        _Pill(icon: Icons.quiz_outlined, label: 'Testlar'),
        _Pill(icon: Icons.campaign_outlined, label: 'E’lonlar'),
        _Pill(icon: Icons.smart_toy_outlined, label: 'Smart AI'),
      ]),
      const SizedBox(height: 20),
      const Text('Asosiy maqsad', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Har bir murojaat e’tiborga olinishi, tekshirilishi va natijasi haqida xabar berilishi kerak.',
        style: TextStyle(color: Colors.black54, height: 1.5)),
    ]),
  );
}

class _ActionCard extends StatelessWidget {
  final IconData icon; final String title, subtitle; final VoidCallback onTap;
  const _ActionCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(20),
    child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: const Color(0xFF2563EB), size: 28),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
      ]))));
}

class _Pill extends StatelessWidget {
  final IconData icon; final String label;
  const _Pill({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 17, color: const Color(0xFF2563EB)),
    label: Text(label), backgroundColor: Colors.white, side: BorderSide.none);
}

class ProblemsPage extends StatefulWidget {
  const ProblemsPage({super.key});
  @override
  State<ProblemsPage> createState() => _ProblemsPageState();
}
class _ProblemsPageState extends State<ProblemsPage> {
  late Future<List<dynamic>> future;
  @override
  void initState() { super.initState(); future = Api.problems(); }
  Future<void> refresh() async { setState(() => future = Api.problems()); await future; }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.transparent,
    appBar: AppBar(title: const Text('Maktab muammolari', style: TextStyle(fontWeight: FontWeight.bold)),
      actions: [IconButton(onPressed: refresh, icon: const Icon(Icons.refresh))]),
    body: FutureBuilder<List<dynamic>>(future: future, builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return _ErrorView(message: 'Serverga ulanib bo‘lmadi.\n${snap.error}', onRetry: refresh);
      final items = snap.data ?? [];
      if (items.isEmpty) return const Center(child: Text('Hozircha muammolar yo‘q.'));
      return RefreshIndicator(onRefresh: refresh, child: ListView.builder(
        padding: const EdgeInsets.all(16), itemCount: items.length,
        itemBuilder: (context, i) => ProblemCard(item: items[i])));
    }),
  );
}

class ProblemCard extends StatelessWidget {
  final Map<String, dynamic> item;
  const ProblemCard({super.key, required this.item});
  @override
  Widget build(BuildContext context) {
    final status = item['status'] ?? 'Yangi yuborildi';
    return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(
      padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(item['title'] ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
          const Icon(Icons.chevron_right, color: Colors.black45)]),
        const SizedBox(height: 8),
        Text(item['description'] ?? '', maxLines: 3, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, children: [
          Chip(label: Text(item['category'] ?? 'Boshqa'), visualDensity: VisualDensity.compact),
          Chip(label: Text(status), backgroundColor: const Color(0xFFDBEAFE), visualDensity: VisualDensity.compact),
        ]),
        Text('${item['school'] ?? ''}  •  #${item['id']}', style: const TextStyle(fontSize: 12, color: Colors.black45)),
      ])));
  }
}

class ReportPage extends StatefulWidget {
  final VoidCallback onSent;
  const ReportPage({super.key, required this.onSent});
  @override
  State<ReportPage> createState() => _ReportPageState();
}
class _ReportPageState extends State<ReportPage> {
  final formKey = GlobalKey<FormState>();
  final title = TextEditingController(), description = TextEditingController(), school = TextEditingController();
  String category = 'Sinfxona', priority = 'O‘rtacha';
  bool sending = false;
  final categories = ['Sinfxona','Parta va stullar','Isitish va sovitish','Elektr','Internet va kompyuter',
    'Hojatxona','Ichimlik suvi','Oshxona','Tozalik','Bino ta’miri','Deraza va eshik','Sport maydoni',
    'Kutubxona','O‘quv materiallari','Qulay kirish','Xavfsizlik','Boshqa'];
  @override
  void dispose() { title.dispose(); description.dispose(); school.dispose(); super.dispose(); }
  Future<void> submit() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => sending = true);
    try {
      await Api.create({'title': title.text.trim(), 'description': description.text.trim(),
        'school': school.text.trim(), 'category': category, 'priority': priority});
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Murojaat muvaffaqiyatli yuborildi')));
      title.clear(); description.clear(); school.clear(); widget.onSent();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Xatolik: $e')));
    } finally { if (mounted) setState(() => sending = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.transparent,
    appBar: AppBar(title: const Text('Muammo yuborish', style: TextStyle(fontWeight: FontWeight.bold))),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Maktabdagi muammoni batafsil yozing. Murojaat yuborilgach, uning holatini kuzatishingiz mumkin.',
        style: TextStyle(color: Colors.black54, height: 1.5)),
      const SizedBox(height: 18),
      TextFormField(controller: title, decoration: const InputDecoration(labelText: 'Muammo sarlavhasi',
        border: OutlineInputBorder(), prefixIcon: Icon(Icons.title)), validator: (v) => (v == null || v.trim().isEmpty) ? 'Sarlavha kiriting' : null),
      const SizedBox(height: 14),
      TextFormField(controller: school, decoration: const InputDecoration(labelText: 'Maktab nomi yoki raqami',
        border: OutlineInputBorder(), prefixIcon: Icon(Icons.school_outlined)), validator: (v) => (v == null || v.trim().isEmpty) ? 'Maktabni kiriting' : null),
      const SizedBox(height: 14),
      DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Muammo turi', border: OutlineInputBorder()),
        items: categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => category = v ?? category)),
      const SizedBox(height: 14),
      DropdownButtonFormField<String>(value: priority, decoration: const InputDecoration(labelText: 'Muhimlik darajasi', border: OutlineInputBorder()),
        items: ['Past','O‘rtacha','Yuqori'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => priority = v ?? priority)),
      const SizedBox(height: 14),
      TextFormField(controller: description, minLines: 5, maxLines: 8,
        decoration: const InputDecoration(labelText: 'Muammo tavsifi', alignLabelWithHint: true, border: OutlineInputBorder()),
        validator: (v) => (v == null || v.trim().length < 10) ? 'Kamida 10 ta belgi yozing' : null),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: sending ? null : submit,
        icon: sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send),
        label: Text(sending ? 'Yuborilmoqda...' : 'Murojaatni yuborish'),
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52))),
      const SizedBox(height: 10),
      const Text('Eslatma: hozirgi MVPda rasm biriktirish va foydalanuvchi akkauntlari hali ulanmagan.',
        style: TextStyle(color: Colors.black45, fontSize: 12)),
    ])),
  );
}

class NoticesPage extends StatelessWidget {
  const NoticesPage({super.key});
  @override
  Widget build(BuildContext context) => const _SimplePage(title: 'Bildirishnomalar',
    icon: Icons.notifications_none, message: 'Hozircha bildirishnomalar yo‘q. Murojaat holati yangilanganda xabarlar shu yerda ko‘rinadi.');
}
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => const _SimplePage(title: 'Profilim',
    icon: Icons.account_circle_outlined, message: 'Profil va ro‘yxatdan o‘tish funksiyalari keyingi bosqichda ulanadi.');
}
class _SimplePage extends StatelessWidget {
  final String title, message; final IconData icon;
  const _SimplePage({required this.title, required this.icon, required this.message});
  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: Colors.transparent,
    appBar: AppBar(title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
    body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 54, color: const Color(0xFF2563EB)),
        const SizedBox(height: 16), Text(message, textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black54, height: 1.5)),
      ]))));
}
class _ErrorView extends StatelessWidget {
  final String message; final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.cloud_off, size: 48, color: Colors.black38),
      const SizedBox(height: 12), Text(message, textAlign: TextAlign.center),
      const SizedBox(height: 12), OutlinedButton(onPressed: onRetry, child: const Text('Qayta urinish')),
    ])));
}
